/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 25
(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AbstractStorage = void 0;
const url_util_1 = __webpack_require__(330);
/**
 * Shared storage logic for Chrome and Firefox.
 *
 * The only browser-specific parts are reading and writing the `settings`
 * object. Keeping the validation/migration logic in one place prevents the two
 * implementations from drifting apart.
 */
class AbstractStorage {
    constructor(initialRules) {
        this._initialRules = () => __awaiter(this, void 0, void 0, function* () {
            try {
                const rules = typeof initialRules === 'function'
                    ? yield initialRules()
                    : yield initialRules;
                return Array.isArray(rules) ? rules : [];
            }
            catch (error) {
                console.warn('Could not load the initial rules', error);
                return [];
            }
        });
        // Make sure the storage object exists and is in a usable state. This is
        // intentionally lazy: on a fresh install the latest rules may still be
        // fetched while the background script is already listening for events.
        this._settingsReady = this.initializeSettings();
    }
    getRules(fn) {
        void this.getValidSettings()
            .then(settings => fn(settings.rules))
            .catch(error => {
            console.error('Could not read phishing rules', error);
            fn([]);
        });
    }
    updateRules(rules_sets) {
        return this.updateSettings(settings => (Object.assign(Object.assign({}, settings), { rules: this.normalizeRules(rules_sets) })));
    }
    getWhitelistedUrls(fn) {
        void this.getValidSettings()
            .then(settings => fn(settings.whitelistedUrls))
            .catch(error => {
            console.error('Could not read whitelisted URLs', error);
            fn([]);
        });
    }
    addWhitelistedUrl(url) {
        const origin = (0, url_util_1.getOrigin)(url);
        if (!origin) {
            return Promise.resolve();
        }
        return this.updateSettings(settings => {
            const whitelistedUrls = new Set(settings.whitelistedUrls);
            whitelistedUrls.add(origin);
            return Object.assign(Object.assign({}, settings), { whitelistedUrls: [...whitelistedUrls] });
        });
    }
    updateLastKnownPhishingUrl(tempUrl) {
        const origin = (0, url_util_1.getOrigin)(tempUrl);
        if (!origin) {
            return Promise.resolve();
        }
        return this.updateSettings(settings => (Object.assign(Object.assign({}, settings), { lastKnownPhishingUrl: origin })));
    }
    getTempUrl(fn) {
        void this.getValidSettings()
            .then(settings => fn(settings.lastKnownPhishingUrl))
            .catch(error => {
            console.error('Could not read the last known phishing URL', error);
            fn(undefined);
        });
    }
    initializeSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.resolveSettings();
        });
    }
    getValidSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this._settingsReady;
            return this.resolveSettings();
        });
    }
    updateSettings(update) {
        return __awaiter(this, void 0, void 0, function* () {
            const settings = yield this.getValidSettings();
            yield this.writeSettings(update(settings));
        });
    }
    resolveSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            let stored;
            let readFailed = false;
            try {
                stored = yield this.readSettings();
            }
            catch (error) {
                // Do not overwrite unknown storage contents when reading failed.
                readFailed = true;
                console.error('Could not read extension settings', error);
            }
            const settings = Object.assign({ rules: Array.isArray(stored === null || stored === void 0 ? void 0 : stored.rules)
                    ? stored.rules
                    : yield this.getInitialRules(), whitelistedUrls: Array.isArray(stored === null || stored === void 0 ? void 0 : stored.whitelistedUrls)
                    ? stored.whitelistedUrls
                    : [] }, (typeof (stored === null || stored === void 0 ? void 0 : stored.lastKnownPhishingUrl) === 'string'
                ? { lastKnownPhishingUrl: stored.lastKnownPhishingUrl }
                : {}));
            if (!readFailed && !this.hasValidSettings(stored)) {
                try {
                    yield this.writeSettings(settings);
                }
                catch (error) {
                    console.error('Could not initialize extension settings', error);
                }
            }
            return settings;
        });
    }
    getInitialRules() {
        if (!this._initialRulesPromise) {
            this._initialRulesPromise = this._initialRules();
        }
        return this._initialRulesPromise;
    }
    hasValidSettings(settings) {
        return (!!settings &&
            Array.isArray(settings.rules) &&
            Array.isArray(settings.whitelistedUrls));
    }
    normalizeRules(rules) {
        if (!Array.isArray(rules) || rules.length < 1) {
            return [];
        }
        if (rules.every(rulesSet => !rulesSet.include && !rulesSet.exclude)) {
            return [];
        }
        return rules;
    }
}
exports.AbstractStorage = AbstractStorage;


/***/ },

/***/ 330
(__unused_webpack_module, exports) {

var __webpack_unused_export__;

/**
 * URL helpers shared by the background script and the extension pages.
 *
 * Browser extensions receive many kinds of URLs (http(s), extension pages,
 * about: pages, etc.). Only http(s) URLs should ever be scanned for phishing.
 */
__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = getParsedUrl;
__webpack_unused_export__ = isHttpUrl;
__webpack_unused_export__ = getHostname;
exports.getOrigin = getOrigin;
function getParsedUrl(url) {
    if (!url) {
        return null;
    }
    try {
        return new URL(url);
    }
    catch (_a) {
        return null;
    }
}
function isHttpUrl(url) {
    const parsed = getParsedUrl(url);
    return (!!parsed && (parsed.protocol === 'http:' || parsed.protocol === 'https:'));
}
function getHostname(url) {
    const parsed = getParsedUrl(url);
    if (!parsed ||
        (parsed.protocol !== 'http:' && parsed.protocol !== 'https:')) {
        return null;
    }
    return parsed.hostname.toLowerCase();
}
/**
 * Returns the origin (protocol + host) of an http(s) URL, or null when the URL
 * is not a valid http(s) URL.
 */
function getOrigin(url) {
    const parsed = getParsedUrl(url);
    if (!parsed ||
        (parsed.protocol !== 'http:' && parsed.protocol !== 'https:')) {
        return null;
    }
    return parsed.origin;
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
let __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
let exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
const abstract_storage_1 = __webpack_require__(25);
class ChromeStorage extends abstract_storage_1.AbstractStorage {
    constructor(initialRules) {
        super(initialRules);
    }
    readSettings() {
        return new Promise(resolve => {
            chrome.storage.local.get('settings', (storageObject) => {
                resolve(storageObject === null || storageObject === void 0 ? void 0 : storageObject.settings);
            });
        });
    }
    writeSettings(settings) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.set({ settings }, () => {
                var _a;
                const error = (_a = chrome.runtime) === null || _a === void 0 ? void 0 : _a.lastError;
                if (error) {
                    reject(new Error(error.message));
                }
                else {
                    resolve();
                }
            });
        });
    }
}
__webpack_unused_export__ = ChromeStorage;

})();

/******/ })()
;